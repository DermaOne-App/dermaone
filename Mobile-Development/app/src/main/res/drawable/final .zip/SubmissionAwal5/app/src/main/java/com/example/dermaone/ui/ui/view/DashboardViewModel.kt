package com.example.dermaone.ui.ui.view

import android.net.Uri
import androidx.lifecycle.ViewModel

class DashboardViewModel : ViewModel() {
    var selectedImageUri: Uri? = null
}