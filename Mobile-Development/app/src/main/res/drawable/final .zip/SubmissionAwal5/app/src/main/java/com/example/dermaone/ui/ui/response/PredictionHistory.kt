package com.example.dermaone.ui.ui.response

class PredictionHistory(
    val name: String,
    val description: String,
    val prediction: String
)