    package com.example.dermaone.ui.ui.response

    class PredictResponse(
        val label: String,
        val confidence: String,
        val imageUrl: String
    )
